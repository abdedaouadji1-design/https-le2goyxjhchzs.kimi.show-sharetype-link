import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

export default function DistributionSection() {
  const { ref, isVisible } = useIntersectionObserver({ threshold: 0.15 });

  const platforms = [
    {
      name: 'Reddit',
      title: 'دس السم في العسل',
      desc: 'ردود قاتلة مفيدة في مجتمعات متخصصة — استخدم أداة التحليل لتوليد ردود احترافية وانشرها كتعليقات',
      bg: '#0A1628',
      border: 'rgba(255, 69, 0, 0.3)',
    },
    {
      name: 'Telegram',
      title: 'هندسة البحث العكسي',
      desc: 'قناة عامة مفهرسة بقوة على جوجل — املأها بمحتوى مفيد واستهدف كلمات مفتاحية محددة',
      bg: '#0D1B30',
      border: 'rgba(0, 136, 204, 0.3)',
    },
    {
      name: 'LinkedIn',
      title: 'تغريدة العصف الذهني',
      desc: 'محتوى صادم يثير النقاش — ناقش المشكلة التي تحلها بأسلوب قوي ومباشر مع سؤال مفتوح',
      bg: '#101D35',
      border: 'rgba(0, 119, 181, 0.3)',
    },
  ];

  return (
    <section
      id="distribution"
      className="relative w-full min-h-[100dvh] flex items-center py-16 md:py-24"
      style={{ backgroundColor: '#050F23' }}
    >
      <div ref={ref} className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2
          className={`font-cairo font-bold text-[var(--gold)] mb-12 text-right transition-all duration-800 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
          }`}
          style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}
        >
          هندسة التوزيع العكسي
        </h2>

        <div className="space-y-6">
          {platforms.map((p, i) => (
            <div
              key={p.name}
              className={`flex flex-col md:flex-row items-start md:items-center gap-6 p-6 rounded-xl border transition-all duration-500 hover:-translate-y-1 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
              }`}
              style={{
                backgroundColor: p.bg,
                borderColor: p.border,
                transitionDelay: `${i * 150}ms`,
                transitionTimingFunction: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
              }}
            >
              <div
                className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0 font-cairo font-bold text-lg"
                style={{
                  backgroundColor: p.border.replace('0.3', '0.15'),
                  color: p.border.replace('0.3', '1'),
                }}
              >
                {p.name[0]}
              </div>
              <div className="flex-1 text-right">
                <h3 className="font-cairo font-bold text-white text-xl mb-1">{p.title}</h3>
                <p className="font-tajawal text-white/60 text-sm leading-relaxed">{p.desc}</p>
              </div>
              <span className="font-cairo text-white/30 text-sm hidden md:block">{p.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

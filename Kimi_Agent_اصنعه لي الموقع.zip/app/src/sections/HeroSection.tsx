import { useEffect, useRef } from 'react';
import { ChevronDown, Play, ArrowLeft } from 'lucide-react';

const PARTICLE_COUNT = 150;
const CONNECTION_DISTANCE = 120;
const MOUSE_REPULSION_RADIUS = 150;

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  baseX: number;
  baseY: number;
}

export default function HeroSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const mouseRef = useRef({ x: -9999, y: -9999 });
  const rafRef = useRef<number>(0);
  const initialized = useRef(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio, 2);
      canvas.width = canvas.offsetWidth * dpr;
      canvas.height = canvas.offsetHeight * dpr;
      ctx.scale(dpr, dpr);
    };
    resize();

    if (!initialized.current) {
      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      particlesRef.current = Array.from({ length: PARTICLE_COUNT }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        baseX: Math.random() * w,
        baseY: Math.random() * h,
      }));
      initialized.current = true;
    }

    const onMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    const onMouseLeave = () => {
      mouseRef.current = { x: -9999, y: -9999 };
    };

    canvas.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('mouseleave', onMouseLeave);
    window.addEventListener('resize', resize);

    const animate = () => {
      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      ctx.clearRect(0, 0, w, h);

      const particles = particlesRef.current;

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        p.vx += (Math.random() - 0.5) * 0.05;
        p.vy += (Math.random() - 0.5) * 0.05;
        p.vx *= 0.99;
        p.vy *= 0.99;

        const dx = p.x - mouseRef.current.x;
        const dy = p.y - mouseRef.current.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < MOUSE_REPULSION_RADIUS && dist > 0) {
          const force = (MOUSE_REPULSION_RADIUS - dist) / MOUSE_REPULSION_RADIUS;
          p.vx += (dx / dist) * force * 0.5;
          p.vy += (dy / dist) * force * 0.5;
        }

        const springX = (p.baseX - p.x) * 0.001;
        const springY = (p.baseY - p.y) * 0.001;
        p.vx += springX;
        p.vy += springY;

        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0) { p.x = 0; p.vx *= -0.5; }
        if (p.x > w) { p.x = w; p.vx *= -0.5; }
        if (p.y < 0) { p.y = 0; p.vy *= -0.5; }
        if (p.y > h) { p.y = h; p.vy *= -0.5; }

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
        ctx.fill();
      }

      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < CONNECTION_DISTANCE) {
            const alpha = (1 - dist / CONNECTION_DISTANCE) * 0.3;
            ctx.strokeStyle = `rgba(212, 175, 55, ${alpha})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      rafRef.current = requestAnimationFrame(animate);
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafRef.current);
      canvas.removeEventListener('mousemove', onMouseMove);
      canvas.removeEventListener('mouseleave', onMouseLeave);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <section
      id="hero"
      className="relative w-full min-h-[100dvh] flex items-center justify-center overflow-hidden"
      style={{ backgroundColor: '#050F23' }}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ zIndex: 1 }}
      />

      <div className="relative z-10 text-center px-4 sm:px-6 max-w-5xl mx-auto">
        <h1
          className="font-cairo font-bold text-white leading-tight mb-4"
          style={{ fontSize: 'clamp(3rem, 7vw, 5rem)' }}
        >
          نُظُم التوثيق الذكي
        </h1>
        <p
          className="text-gold-light font-tajawal mb-10 max-w-3xl mx-auto leading-relaxed"
          style={{ fontSize: 'clamp(1rem, 2vw, 1.2rem)' }}
        >
          أداة مايكرو-ساس متخصصة في توليد الوثائق القانونية والإدارية الاحترافية باللهجة العربية المحكمة والمصممة خصيصاً للسياقات المحلية في دول مجلس التعاون الخليجي ومصر
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4">
          <button className="interactive px-8 py-3 rounded-full bg-gold text-[#050F23] font-cairo font-semibold text-base transition-all duration-300 hover:-translate-y-1 hover:shadow-gold">
            ابدأ الآن
          </button>
          <button className="interactive px-8 py-3 rounded-full border border-[var(--gold)] text-[var(--gold)] font-cairo font-semibold text-base transition-all duration-300 hover:-translate-y-1 hover:bg-[var(--gold)] hover:text-[#050F23]">
            <ArrowLeft className="inline-block ml-2 w-4 h-4" />
            تعرف على المزيد
          </button>
          <button className="interactive px-8 py-3 rounded-full border border-[#8A92A5] text-white font-cairo font-semibold text-base transition-all duration-300 hover:-translate-y-1 hover:border-white flex items-center gap-2">
            <Play className="w-4 h-4" />
            شاهد العرض
          </button>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-pulse-glow">
        <ChevronDown className="w-6 h-6 text-[var(--gold)]" />
      </div>
    </section>
  );
}

export default function TickerSection() {
  const items = [
    'عقود عمل سعودية',
    'اتفاقيات سرية',
    'شكاوى عمالية',
    'خطابات تظلم',
    'ردود رسمية فورية',
    'وثائق قانونية دقيقة',
  ];

  const tickerText = items.join(' \u00B7 ');

  return (
    <section className="w-full py-4 overflow-hidden border-y border-[var(--gold)]/30 bg-[#050F23]/80 backdrop-blur-sm">
      <div className="group">
        <div className="flex whitespace-nowrap animate-ticker group-hover:[animation-play-state:paused]">
          <span className="text-[var(--gold)] font-tajawal text-[1.1rem] px-4 select-none">
            {tickerText} &nbsp;&nbsp;&nbsp; {tickerText} &nbsp;&nbsp;&nbsp;
          </span>
          <span className="text-[var(--gold)] font-tajawal text-[1.1rem] px-4 select-none">
            {tickerText} &nbsp;&nbsp;&nbsp; {tickerText} &nbsp;&nbsp;&nbsp;
          </span>
        </div>
      </div>
    </section>
  );
}

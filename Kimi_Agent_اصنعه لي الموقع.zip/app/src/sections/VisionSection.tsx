import { FileText, Stamp, Mail, Bell } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

export default function VisionSection() {
  const { ref, isVisible } = useIntersectionObserver({ threshold: 0.15 });

  return (
    <section
      id="vision"
      className="relative w-full min-h-[100dvh] flex items-center py-16 md:py-24"
      style={{ backgroundColor: '#050F23' }}
    >
      <div
        ref={ref}
        className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center gap-12"
      >
        {/* Text */}
        <div
          className={`flex-1 text-right transition-all duration-800 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
          }`}
          style={{ transitionTimingFunction: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)' }}
        >
          <h2
            className="font-cairo font-bold text-[var(--gold)] mb-6"
            style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}
          >
            رؤيتنا
          </h2>
          <p className="font-tajawal text-white/90 text-lg md:text-xl leading-[1.8] max-w-2xl">
            نُظُم التوثيق الذكي هي أداة مايكرو-ساس متخصصة في توليد الوثائق القانونية والإدارية الاحترافية باللهجة العربية المحكمة. نملأ الثغرة بين الحلول المجانية العامة والخدمات القانونية المكلفة، بأسلوب ذكي ومخصص لسياقات دول مجلس التعاون الخليجي ومصر.
          </p>
          <div className="mt-6 w-24 h-1 bg-gradient-to-l from-[var(--gold)] to-transparent rounded-full" />
        </div>

        {/* Icons */}
        <div
          className={`flex flex-wrap justify-center gap-8 flex-1 transition-all duration-1000 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
          }`}
        >
          {[
            { icon: FileText, label: 'عقود' },
            { icon: Stamp, label: 'ختم' },
            { icon: Mail, label: 'خطاب' },
            { icon: Bell, label: 'إشعار' },
          ].map(({ icon: Icon, label }, i) => (
            <div
              key={label}
              className="flex flex-col items-center gap-3 p-6 rounded-2xl border border-[var(--gold)]/20 hover:border-[var(--gold)]/60 hover:scale-105 transition-all duration-400"
              style={{ animationDelay: `${i * 150}ms` }}
            >
              <Icon className="w-10 h-10 text-[var(--gold)]" strokeWidth={1.5} />
              <span className="text-white/70 font-tajawal text-sm">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

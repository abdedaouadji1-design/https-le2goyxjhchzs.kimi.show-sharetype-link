import CustomCursor from '../components/CustomCursor';
import Navbar from '../components/Navbar';
import HeroSection from '../sections/HeroSection';
import TickerSection from '../sections/TickerSection';
import VisionSection from '../sections/VisionSection';
import ProductSection from '../sections/ProductSection';
import FeaturesSection from '../sections/FeaturesSection';
import SplitStorySection from '../sections/SplitStorySection';
import IntelligenceSection from '../sections/IntelligenceSection';
import MarketGapSection from '../sections/MarketGapSection';
import DistributionSection from '../sections/DistributionSection';
import FinalCTASection from '../sections/FinalCTASection';

export default function Home() {
  return (
    <div className="relative" style={{ backgroundColor: '#050F23' }}>
      <CustomCursor />
      <Navbar />
      <main role="main">
        <HeroSection />
        <TickerSection />
        <VisionSection />
        <ProductSection />
        <FeaturesSection />
        <SplitStorySection />
        <IntelligenceSection />
        <MarketGapSection />
        <DistributionSection />
        <FinalCTASection />
      </main>
    </div>
  );
}

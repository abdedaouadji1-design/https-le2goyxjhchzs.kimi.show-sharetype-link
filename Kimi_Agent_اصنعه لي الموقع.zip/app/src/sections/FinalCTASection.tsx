import { useEffect, useRef } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

const RING_COUNT = 25;
const RING_SPEED = 4;
const MAX_Z = 2000;

export default function FinalCTASection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ringsRef = useRef<{ z: number }[]>([]);
  const rafRef = useRef<number>(0);
  const isActiveRef = useRef(false);
  const timeRef = useRef(0);
  const { ref: observerRef, isVisible } = useIntersectionObserver({ threshold: 0.1 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio, 2);
      canvas.width = canvas.offsetWidth * dpr;
      canvas.height = canvas.offsetHeight * dpr;
      ctx.scale(dpr, dpr);
    };
    resize();

    if (ringsRef.current.length === 0) {
      ringsRef.current = Array.from({ length: RING_COUNT }, (_, i) => ({
        z: (i / RING_COUNT) * MAX_Z,
      }));
    }

    window.addEventListener('resize', resize);

    const animate = () => {
      if (!isActiveRef.current) {
        rafRef.current = requestAnimationFrame(animate);
        return;
      }

      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      timeRef.current += 0.01;
      const t = timeRef.current;

      ctx.clearRect(0, 0, w, h);

      const cx = w / 2 + Math.sin(t * 0.3) * 30;
      const cy = h / 2 + Math.cos(t * 0.2) * 20;
      const perspective = 300;

      for (const ring of ringsRef.current) {
        ring.z -= RING_SPEED;
        if (ring.z < 10) ring.z = MAX_Z;

        const depthFactor = perspective / (perspective + ring.z);
        const radius = 200 * depthFactor;
        const progress = 1 - ring.z / MAX_Z;

        const r = Math.round(212 * (1 - progress) + 5 * progress);
        const g = Math.round(175 * (1 - progress) + 15 * progress);
        const b = Math.round(55 * (1 - progress) + 35 * progress);
        const alpha = depthFactor * 0.6;

        ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, ${alpha})`;
        ctx.lineWidth = 2 * depthFactor;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.stroke();
      }

      rafRef.current = requestAnimationFrame(animate);
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
    };
  }, []);

  useEffect(() => {
    isActiveRef.current = isVisible;
  }, [isVisible]);

  const steps = [
    'الساعة الأولى: أنشئ مستودعاً على GitHub وافتح Codespaces',
    'الساعة الثانية: أنشئ بوت تيليجرام واحفظ التوكن',
    'الساعة الثالثة: ابدأ كتابة كود البوت بـ Gemini Code Assist',
    'الساعة الرابعة: افتح حساباً على Buy Me A Coffee',
  ];

  return (
    <section
      id="cta"
      ref={observerRef}
      className="relative w-full min-h-[100dvh] flex items-center py-16 md:py-24 overflow-hidden"
      style={{ backgroundColor: '#050F23' }}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ zIndex: 1 }}
      />

      <div className="relative z-10 w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2
          className={`font-cairo font-bold text-[var(--gold)] mb-10 transition-all duration-800 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
          }`}
          style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}
        >
          خريطة عمليات الليلة
        </h2>

        <div className="space-y-4 mb-10">
          {steps.map((step, i) => (
            <div
              key={i}
              className={`p-4 rounded-lg border border-white/5 text-right transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
              }`}
              style={{
                backgroundColor: 'rgba(10, 22, 40, 0.7)',
                transitionDelay: `${(i + 1) * 150}ms`,
                transitionTimingFunction: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
              }}
            >
              <div className="flex items-center gap-3 justify-end">
                <span className="font-tajawal text-white/80 text-sm md:text-base">{step}</span>
                <span className="w-6 h-6 rounded-full bg-[var(--gold)]/20 flex items-center justify-center flex-shrink-0">
                  <span className="font-cairo font-bold text-[var(--gold)] text-xs">{i + 1}</span>
                </span>
              </div>
            </div>
          ))}
        </div>

        <button
          className={`interactive px-10 py-4 rounded-full bg-gold text-[#050F23] font-cairo font-bold text-[1.3rem] transition-all duration-300 hover:-translate-y-1 hover:shadow-gold ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
          }`}
          style={{
            transitionDelay: '800ms',
            transitionTimingFunction: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
          }}
        >
          ابدأ رحلتك الآن
        </button>

        <footer
          className={`mt-16 pt-8 border-t border-white/5 transition-all duration-1000 delay-1000 ${
            isVisible ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <p className="font-tajawal text-white/30 text-sm">
            &copy; 2025 DocumentForge AI — والله ولي التوفيق
          </p>
        </footer>
      </div>
    </section>
  );
}

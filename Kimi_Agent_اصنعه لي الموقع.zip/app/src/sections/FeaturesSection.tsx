import { Shield, CheckCircle, Lock, Globe } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

export default function FeaturesSection() {
  const { ref, isVisible } = useIntersectionObserver({ threshold: 0.15 });

  const features = [
    {
      icon: Shield,
      title: 'الثقة الفورية',
      desc: 'ختم رقمي وإشعار امتثال لكل وثيقة تُنتجها المنصة',
      num: '01',
    },
    {
      icon: CheckCircle,
      title: 'التحقق المزدوج',
      desc: 'خدمة تحقق بشري من مستشار قانوني متعاقد معنا',
      num: '02',
    },
    {
      icon: Lock,
      title: 'الخصوصية القصوى',
      desc: 'معالجة لحظية آمنة بدون تخزين أي بيانات',
      num: '03',
    },
    {
      icon: Globe,
      title: 'التخصص الجغرافي',
      desc: 'ردود متوافقة مع السياق الثقافي والقانوني لكل دولة',
      num: '04',
    },
  ];

  return (
    <section
      id="features"
      className="relative w-full min-h-[100dvh] flex items-center py-16 md:py-24"
      style={{ backgroundColor: '#050F23' }}
    >
      <div ref={ref} className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2
          className={`font-cairo font-bold text-[var(--gold)] mb-12 text-right transition-all duration-800 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
          }`}
          style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}
        >
          لماذا DocumentForge AI؟
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <div
              key={f.num}
              className={`relative p-6 rounded-xl border border-white/5 hover:border-[var(--gold)]/30 transition-all duration-400 hover:-translate-y-1 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
              }`}
              style={{
                backgroundColor: 'rgba(10, 22, 40, 0.6)',
                transitionDelay: `${i * 120}ms`,
                transitionTimingFunction: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
              }}
            >
              <span
                className="absolute top-4 left-4 font-cairo font-bold text-5xl leading-none select-none"
                style={{ color: 'rgba(212, 175, 55, 0.15)' }}
              >
                {f.num}
              </span>
              <div className="w-12 h-12 rounded-lg bg-[var(--gold)]/10 flex items-center justify-center mb-4">
                <f.icon className="w-6 h-6 text-[var(--gold)]" strokeWidth={1.5} />
              </div>
              <h3 className="font-cairo font-bold text-white text-lg mb-2">{f.title}</h3>
              <p className="font-tajawal text-white/60 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

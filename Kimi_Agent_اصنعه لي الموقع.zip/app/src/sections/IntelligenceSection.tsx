import { useEffect, useRef } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

const SEGMENTS = 3000;
const SEGMENT_LENGTH = 20;

function noise(x: number, y: number, t: number): number {
  return Math.sin(x * 0.003 + t) * Math.cos(y * 0.003 + t * 0.7) +
         Math.sin(x * 0.01 - t * 0.5) * 0.5;
}

export default function IntelligenceSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const timeRef = useRef(0);
  const rafRef = useRef<number>(0);
  const isActiveRef = useRef(false);
  const segmentsRef = useRef<{ x: number; y: number; angle: number; hue: number }[]>([]);
  const { ref: observerRef, isVisible } = useIntersectionObserver({ threshold: 0.1 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio, 2);
      canvas.width = canvas.offsetWidth * dpr;
      canvas.height = canvas.offsetHeight * dpr;
      ctx.scale(dpr, dpr);

      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      segmentsRef.current = Array.from({ length: SEGMENTS }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        angle: Math.random() * Math.PI * 2,
        hue: 40 + Math.random() * 10,
      }));
    };
    resize();
    window.addEventListener('resize', resize);

    const animate = () => {
      if (!isActiveRef.current) {
        rafRef.current = requestAnimationFrame(animate);
        return;
      }

      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      timeRef.current += 0.0005;
      const t = timeRef.current;

      ctx.fillStyle = 'rgba(5, 15, 35, 0.05)';
      ctx.fillRect(0, 0, w, h);

      const segments = segmentsRef.current;

      for (let i = 0; i < segments.length; i++) {
        const s = segments[i];
        const angle = noise(s.x, s.y, t) * Math.PI * 2;
        s.angle = angle;
        s.x += Math.cos(angle) * 0.5;
        s.y += Math.sin(angle) * 0.5;

        if (s.x < 0) s.x = w;
        if (s.x > w) s.x = 0;
        if (s.y < 0) s.y = h;
        if (s.y > h) s.y = 0;

        const lightness = 50 + Math.sin(t * 2 + i * 0.001) * 20;
        ctx.strokeStyle = `hsl(${s.hue}, 80%, ${lightness}%)`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(
          s.x + Math.cos(s.angle) * SEGMENT_LENGTH,
          s.y + Math.sin(s.angle) * SEGMENT_LENGTH
        );
        ctx.stroke();
      }

      rafRef.current = requestAnimationFrame(animate);
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
    };
  }, []);

  useEffect(() => {
    isActiveRef.current = isVisible;
  }, [isVisible]);

  const agents = [
    {
      title: 'وكيل المنتج',
      desc: 'توليد خدمات رقمية دقيقة (Micro-Services) قابلة للبيع الفوري',
    },
    {
      title: 'وكيل الواجهة',
      desc: 'بناء وتحديث واجهة المتجر الإلكتروني بشكل تلقائي ومستمر',
    },
    {
      title: 'وكيل التسويق',
      desc: 'توليد محتوى تسويقي صادم ونشره في قنوات توزيع عضوية بحتة',
    },
  ];

  return (
    <section
      id="intelligence"
      ref={observerRef}
      className="relative w-full min-h-[100dvh] flex items-center py-16 md:py-24 overflow-hidden"
      style={{ backgroundColor: '#050F23' }}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ zIndex: 1 }}
      />

      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`text-center mb-12 transition-all duration-800 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
          }`}
        >
          <h2
            className="font-cairo font-bold text-[var(--gold)] mb-4"
            style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}
          >
            محرك الذكاء الاصطناعي
          </h2>
          <p className="font-tajawal text-white/70 text-lg max-w-2xl mx-auto">
            نظام يحول الهاتف الذكي إلى مدير شركة افتراضي يعمل 24/7
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {agents.map((agent, i) => (
            <div
              key={agent.title}
              className={`p-6 rounded-xl transition-all duration-500 hover:-translate-y-1 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
              }`}
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.95)',
                color: '#050F23',
                transitionDelay: `${i * 150}ms`,
                transitionTimingFunction: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
              }}
            >
              <div className="w-10 h-10 rounded-lg bg-[#050F23]/10 flex items-center justify-center mb-4">
                <span className="font-cairo font-bold text-[#050F23] text-lg">{i + 1}</span>
              </div>
              <h3 className="font-cairo font-bold text-[#050F23] text-xl mb-2">{agent.title}</h3>
              <p className="font-tajawal text-[#050F23]/70 text-sm leading-relaxed">{agent.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

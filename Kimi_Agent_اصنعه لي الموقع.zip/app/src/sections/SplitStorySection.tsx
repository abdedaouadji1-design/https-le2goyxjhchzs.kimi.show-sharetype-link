import { useEffect, useRef } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

const RINGS = 20;
const VERTICES = 8;
const TIME_INCREMENT = 0.02;
const ROTATION_SPEED = 0.002;

export default function SplitStorySection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const timeRef = useRef(0);
  const rafRef = useRef<number>(0);
  const isActiveRef = useRef(false);
  const { ref: observerRef, isVisible } = useIntersectionObserver({ threshold: 0.1 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio, 2);
      canvas.width = canvas.offsetWidth * dpr;
      canvas.height = canvas.offsetHeight * dpr;
      ctx.scale(dpr, dpr);
    };
    resize();
    window.addEventListener('resize', resize);

    const animate = () => {
      if (!isActiveRef.current) {
        rafRef.current = requestAnimationFrame(animate);
        return;
      }

      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      timeRef.current += TIME_INCREMENT;
      const t = timeRef.current;

      ctx.clearRect(0, 0, w, h);

      const cx = w / 2;
      const cy = h / 2;
      const perspective = 300;
      const maxZ = 2000;
      const spacing = maxZ / RINGS;

      for (let r = 0; r < RINGS; r++) {
        const z = r * spacing;
        const depthFactor = perspective / (perspective + z);
        const radius = 120 * depthFactor;
        const xOffset = cx + Math.sin(t * 0.3) * 30 * depthFactor;
        const yOffset = cy + Math.cos(t * 0.2) * 20 * depthFactor;

        const points: { x: number; y: number }[] = [];
        for (let v = 0; v <= VERTICES; v++) {
          const angle = (v / VERTICES) * Math.PI * 2 + t * ROTATION_SPEED;
          const px = xOffset + Math.cos(angle) * radius;
          const py = yOffset + Math.sin(angle) * radius;
          points.push({ x: px, y: py });
        }

        const alpha = (1 - z / maxZ) * 0.25;
        ctx.strokeStyle = `rgba(180, 140, 50, ${alpha})`;
        ctx.lineWidth = 1;

        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
          ctx.lineTo(points[i].x, points[i].y);
        }
        ctx.closePath();
        ctx.stroke();
      }

      rafRef.current = requestAnimationFrame(animate);
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
    };
  }, []);

  useEffect(() => {
    isActiveRef.current = isVisible;
  }, [isVisible]);

  const layers = [
    {
      title: 'طبقة التوليد',
      color: 'var(--gold)',
      items: ['وكيل المنتج (Product Agent)', 'وكيل الواجهة (Interface Agent)', 'وكيل التسويق (Marketing Agent)'],
    },
    {
      title: 'طبقة التنفيذ',
      color: 'var(--gold-light)',
      items: ['Telegram Bot كخادم', 'Buy Me A Coffee للدفع', 'API لنماذج الذكاء الاصطناعي'],
    },
    {
      title: 'طبقة التحسين الذاتي',
      color: '#B48C32',
      items: ['تحليلات الأداء', 'تحسين الأسعار تلقائياً', 'توليد خدمات جديدة'],
    },
  ];

  return (
    <section
      id="system"
      ref={observerRef}
      className="relative w-full min-h-[100dvh] flex items-center py-16 md:py-24 overflow-hidden"
      style={{ backgroundColor: '#050F23' }}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ zIndex: 1 }}
      />

      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-start gap-12">
          {/* Text */}
          <div
            className={`flex-1 text-right transition-all duration-800 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
            }`}
          >
            <h2
              className="font-cairo font-bold text-[var(--gold)] mb-8"
              style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}
            >
              النظام المتكامل ذاتي التغذية
            </h2>

            <div className="space-y-6">
              {layers.map((layer, i) => (
                <div
                  key={layer.title}
                  className={`p-5 rounded-xl border-r-4 transition-all duration-500 ${
                    isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'
                  }`}
                  style={{
                    borderColor: layer.color,
                    backgroundColor: 'rgba(10, 22, 40, 0.7)',
                    transitionDelay: `${(i + 1) * 200}ms`,
                  }}
                >
                  <h3 className="font-cairo font-bold text-white text-lg mb-2">{layer.title}</h3>
                  <ul className="space-y-1">
                    {layer.items.map((item) => (
                      <li key={item} className="font-tajawal text-white/70 text-sm flex items-center gap-2 justify-end">
                        <span>{item}</span>
                        <span className="w-1.5 h-1.5 rounded-full bg-[var(--gold)]" />
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Diagram */}
          <div
            className={`flex-1 flex items-center justify-center transition-all duration-1000 delay-300 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
            }`}
          >
            <svg viewBox="0 0 300 400" className="w-full max-w-sm opacity-60">
              {layers.map((layer, i) => {
                const y = 60 + i * 120;
                return (
                  <g key={layer.title}>
                    <rect
                      x="50"
                      y={y - 40}
                      width="200"
                      height="80"
                      rx="12"
                      fill="none"
                      stroke={layer.color}
                      strokeWidth="2"
                      strokeOpacity="0.8"
                    />
                    <rect
                      x="50"
                      y={y - 40}
                      width="200"
                      height="80"
                      rx="12"
                      fill={layer.color}
                      fillOpacity="0.08"
                    />
                    <text
                      x="150"
                      y={y - 5}
                      textAnchor="middle"
                      fill="white"
                      fontSize="14"
                      fontFamily="Cairo"
                      fontWeight="600"
                    >
                      {layer.title}
                    </text>
                    {i < layers.length - 1 && (
                      <line
                        x1="150"
                        y1={y + 40}
                        x2="150"
                        y2={y + 80}
                        stroke="var(--gold)"
                        strokeWidth="2"
                        strokeDasharray="6 4"
                        opacity="0.5"
                      />
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
}

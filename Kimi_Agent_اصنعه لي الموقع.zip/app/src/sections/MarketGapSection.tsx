import { useEffect, useRef } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

const LINE_COUNT = 40;
const TIME_INCREMENT = 0.015;

export default function MarketGapSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: -9999, y: -9999 });
  const timeRef = useRef(0);
  const rafRef = useRef<number>(0);
  const isActiveRef = useRef(false);
  const { ref: observerRef, isVisible } = useIntersectionObserver({ threshold: 0.1 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio, 2);
      canvas.width = canvas.offsetWidth * dpr;
      canvas.height = canvas.offsetHeight * dpr;
      ctx.scale(dpr, dpr);
    };
    resize();

    const onMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    const onMouseLeave = () => {
      mouseRef.current = { x: -9999, y: -9999 };
    };

    canvas.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('mouseleave', onMouseLeave);
    window.addEventListener('resize', resize);

    const lines = Array.from({ length: LINE_COUNT }, (_, i) => ({
      y: i / LINE_COUNT,
      freq: 0.5 + Math.random() * 2,
      amp: 30 + Math.random() * 50,
      phase: Math.random() * Math.PI * 2,
    }));

    const animate = () => {
      if (!isActiveRef.current) {
        rafRef.current = requestAnimationFrame(animate);
        return;
      }

      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      timeRef.current += TIME_INCREMENT;
      const t = timeRef.current;

      ctx.clearRect(0, 0, w, h);
      ctx.save();
      ctx.globalCompositeOperation = 'screen';

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const baseY = line.y * h;

        const mousePhaseShift =
          mouseRef.current.x >= 0
            ? Math.sin((baseY - mouseRef.current.y) * 0.01) * 0.5
            : 0;

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
        ctx.lineWidth = 1;
        ctx.beginPath();

        for (let x = 0; x <= w; x += 3) {
          const y =
            baseY +
            Math.sin(x * 0.008 * line.freq + t + line.phase + mousePhaseShift) *
              line.amp;
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }

        ctx.stroke();
      }

      ctx.restore();

      rafRef.current = requestAnimationFrame(animate);
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafRef.current);
      canvas.removeEventListener('mousemove', onMouseMove);
      canvas.removeEventListener('mouseleave', onMouseLeave);
      window.removeEventListener('resize', resize);
    };
  }, []);

  useEffect(() => {
    isActiveRef.current = isVisible;
  }, [isVisible]);

  const steps = [
    { num: '01', title: 'ألصق نص الإشعار', desc: 'انسخ والصق النص الأصلي الذي تلقيته' },
    { num: '02', title: 'اختر نوع الرد', desc: 'تظلم، استفسار، اعتذار، أو غيرها' },
    { num: '03', title: 'احصل على رد جاهز في 60 ثانية', desc: 'رد كامل ومهذب ومتوافق مع السياق القانوني' },
  ];

  return (
    <section
      id="market"
      ref={observerRef}
      className="relative w-full min-h-[100dvh] flex items-center py-16 md:py-24 overflow-hidden"
      style={{ backgroundColor: '#050F23' }}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ zIndex: 1 }}
      />

      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`text-right mb-12 transition-all duration-800 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
          }`}
        >
          <h2
            className="font-cairo font-bold text-[var(--gold)] mb-4"
            style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}
          >
            ثغرة الـ 60 ثانية
          </h2>
          <p className="font-tajawal text-white/80 text-lg max-w-2xl">
            مولد الردود الرسمية الفورية للجهات الحكومية والخاصة — رد متوافق مع السياق الثقافي والقانوني لكل دولة عربية
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          {steps.map((step, i) => (
            <div
              key={step.num}
              className={`flex-1 flex items-start gap-4 p-6 rounded-xl border border-white/5 hover:border-[var(--gold)]/30 transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
              }`}
              style={{
                backgroundColor: 'rgba(10, 22, 40, 0.7)',
                transitionDelay: `${i * 200}ms`,
                transitionTimingFunction: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
              }}
            >
              <div className="w-12 h-12 rounded-full border-2 border-[var(--gold)] flex items-center justify-center flex-shrink-0">
                <span className="font-cairo font-bold text-[var(--gold)]">{step.num}</span>
              </div>
              <div className="text-right">
                <h3 className="font-cairo font-bold text-white text-lg mb-1">{step.title}</h3>
                <p className="font-tajawal text-white/60 text-sm">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

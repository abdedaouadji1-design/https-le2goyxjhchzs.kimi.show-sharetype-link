import { useEffect, useRef } from 'react';
import { Zap, BookOpen, Lock, UserCheck } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

const MOUSE_INFLUENCE = 200;

function simplexNoise(x: number, y: number, t: number): number {
  return Math.sin(x * 0.05 + t) * Math.cos(y * 0.05 + t * 0.7) * 0.5 +
         Math.sin(x * 0.1 - t * 0.5) * Math.cos(y * 0.08 + t * 1.2) * 0.3 +
         Math.sin((x + y) * 0.03 + t * 0.3) * 0.2;
}

export default function ProductSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: -9999, y: -9999 });
  const timeRef = useRef(0);
  const rafRef = useRef<number>(0);
  const sectionRef = useRef<HTMLDivElement>(null);
  const isActiveRef = useRef(false);
  const { ref: observerRef, isVisible } = useIntersectionObserver({ threshold: 0.1 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio, 2);
      canvas.width = canvas.offsetWidth * dpr;
      canvas.height = canvas.offsetHeight * dpr;
      ctx.scale(dpr, dpr);
    };
    resize();

    const onMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    const onMouseLeave = () => {
      mouseRef.current = { x: -9999, y: -9999 };
    };

    canvas.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('mouseleave', onMouseLeave);
    window.addEventListener('resize', resize);

    const animate = () => {
      if (!isActiveRef.current) {
        rafRef.current = requestAnimationFrame(animate);
        return;
      }

      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      timeRef.current += 0.005;
      const t = timeRef.current;

      ctx.clearRect(0, 0, w, h);

      const cols = 30;
      const rows = 20;
      const cellW = w / cols;
      const cellH = h / rows;
      const vertices: { x: number; y: number; z: number }[][] = [];

      for (let r = 0; r <= rows; r++) {
        vertices[r] = [];
        for (let c = 0; c <= cols; c++) {
          const px = c * cellW;
          const py = r * cellH;
          let z = simplexNoise(c, r, t) * 30;

          const mdx = px - mouseRef.current.x;
          const mdy = py - mouseRef.current.y;
          const mDist = Math.sqrt(mdx * mdx + mdy * mdy);
          if (mDist < MOUSE_INFLUENCE) {
            z += (1 - mDist / MOUSE_INFLUENCE) * 40;
          }

          vertices[r][c] = { x: px, y: py, z };
        }
      }

      ctx.strokeStyle = 'rgba(212, 175, 55, 0.15)';
      ctx.lineWidth = 1;

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const v0 = vertices[r][c];
          const v1 = vertices[r][c + 1];
          const v2 = vertices[r + 1][c];
          const v3 = vertices[r + 1][c + 1];

          ctx.beginPath();
          ctx.moveTo(v0.x + v0.z * 0.5, v0.y + v0.z * 0.3);
          ctx.lineTo(v1.x + v1.z * 0.5, v1.y + v1.z * 0.3);
          ctx.lineTo(v3.x + v3.z * 0.5, v3.y + v3.z * 0.3);
          ctx.lineTo(v2.x + v2.z * 0.5, v2.y + v2.z * 0.3);
          ctx.closePath();
          ctx.stroke();
        }
      }

      rafRef.current = requestAnimationFrame(animate);
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafRef.current);
      canvas.removeEventListener('mousemove', onMouseMove);
      canvas.removeEventListener('mouseleave', onMouseLeave);
      window.removeEventListener('resize', resize);
    };
  }, []);

  useEffect(() => {
    isActiveRef.current = isVisible;
  }, [isVisible]);

  const cards = [
    { icon: Zap, title: 'توليد فوري', desc: 'وثيقة جاهزة في 60 ثانية' },
    { icon: BookOpen, title: 'قوالب قانونية', desc: 'مخصصة لكل دولة عربية' },
    { icon: Lock, title: 'خصوصية تامة', desc: 'لا يحفظ أي بيانات' },
    { icon: UserCheck, title: 'تحقق بشري', desc: 'مراجعة قانونية إضافية' },
  ];

  return (
    <section
      id="product"
      ref={observerRef}
      className="relative w-full min-h-[100dvh] flex items-center py-16 md:py-24 overflow-hidden"
      style={{ backgroundColor: '#050F23' }}
    >
      <div
        ref={sectionRef}
        className="absolute inset-0"
      >
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full"
          style={{ zIndex: 1 }}
        />
      </div>

      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`text-right mb-12 transition-all duration-800 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
          }`}
        >
          <h2
            className="font-cairo font-bold text-[var(--gold)] mb-4"
            style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}
          >
            الأداة الخارقة: صانع الوثائق الذكية
          </h2>
          <p className="font-tajawal text-white/80 text-lg max-w-2xl">
            DocumentForge AI — مكتبة قوالب متخصصة ومصممة بعناية، تستخدم واجهة Gemini API لملء القوالب بناءً على مدخلات بسيطة
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {cards.map((card, i) => (
            <div
              key={card.title}
              className={`group relative p-8 rounded-2xl border border-[var(--gold)]/20 hover:border-[var(--gold)]/50 transition-all duration-400 hover:scale-[1.02] hover:shadow-lg hover:shadow-[var(--gold)]/10 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[60px]'
              }`}
              style={{
                backgroundColor: 'rgba(10, 22, 40, 0.8)',
                backdropFilter: 'blur(10px)',
                transitionDelay: `${i * 100}ms`,
                transitionTimingFunction: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
                aspectRatio: '16/10',
              }}
            >
              <div className="w-14 h-14 rounded-xl bg-[var(--gold)]/10 flex items-center justify-center mb-4 group-hover:bg-[var(--gold)]/20 transition-colors">
                <card.icon className="w-7 h-7 text-[var(--gold)]" strokeWidth={1.5} />
              </div>
              <h3 className="font-cairo font-bold text-white text-xl mb-2">{card.title}</h3>
              <p className="font-tajawal text-white/60 text-base">{card.desc}</p>
              <div className="absolute top-4 left-4 w-8 h-8 rounded-full border border-[var(--gold)]/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <span className="text-[var(--gold)] text-xs font-cairo">{i + 1}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
